package entities;

public class LivroDeReceitas {

	private String receitasSalvas;

	public LivroDeReceitas() {

	}

	public LivroDeReceitas(String receitasSalvas) {

		this.receitasSalvas = receitasSalvas;
	}

	public String getReceitasSalvas() {
		return receitasSalvas;
	}

	public void editarReceita() {
		return;
	}

	public void removerReceita() {
		return;
	}

	public void compartilharReceita() {
		return;
	}

	public void salvarReceita() {
		return;
	}

	public void mostrarReceitas() {
		return;
	}

	public void pesquisarReceita() {
		return;
	}
}
